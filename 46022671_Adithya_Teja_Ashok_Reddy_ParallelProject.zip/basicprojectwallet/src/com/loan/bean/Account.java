package com.loan.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Account implements Serializable {
	private  static final long SerialVersionUID = 1L; 
	@Id
	int accNumber;
	String firstName;
	String phNo;
	double balanceAmt;
	String id;
	String pass;
	double loanAmount,emi;
	int transcount;
	
	
	public Account()
	{
		
	}
	
	
	public Account(String firstName, String phNo, double balnc,String uid, String pwd) {
		super();
		this.firstName = firstName;
		this.phNo = phNo;
		this.balanceAmt = balnc;
		this.id = uid;
		this.pass =pwd;
	}


	public int getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getPhNo() {
		return phNo;
	}

	public void setPhNo(String phNo) {
		this.phNo = phNo;
	}

	public double getBalanceAmt() {
		return balanceAmt;
	}

	public void setBalanceAmt(double balanceAmt) {
		this.balanceAmt = balanceAmt;
	}
	

	public String getUid() {
		return id;
	}

	
	public void setUid(String uid) {
		this.id = uid;
	}

	
	public String getPwd() {
		return pass;
	}

	public void setPwd(String pwd) {
		this.pass = pwd;
	}
	
	public double getLoanAmount() {
		return loanAmount;
	}


	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}


	public double getEmi() {
		return emi;
	}


	public void setEmi(double emi) {
		this.emi = emi;
	}

	
	public int getTransCount() {
		return transcount;
	}


	public void setTransCount(int transcount) {
		this.transcount = transcount;
	}


	@Override
	public String toString() {
		return " Account Number: " +accNumber +"\n Name: "+firstName +"\n Mobile Number: " +phNo +"\n UID: "+id+"\n Balance Amount: Rs."+balanceAmt+"\n Loan Amount: Rs."+loanAmount;
	}
	
	
	

}
