package com.loan.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Transactions implements Serializable {
	private  static final long SerialVersionUID = 1L;
	@Id
	@SequenceGenerator(name="myseq",sequenceName="seq2")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
	int id;
	int accNumber;
	int transId;
	String trans;
	
	public Transactions()
	{
		
	}
	public Transactions(int accNumber, int transCount, String trans) {
		super();
		this.accNumber = accNumber;
		this.transId = transCount;
		this.trans = trans;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTrans() {
		return trans;
	}
	public void setTrans(String trans) {
		this.trans = trans;
	}
	@Override
	public String toString() {
		return "accNumber=" + accNumber + ", transId=" + transId + ", trans=" + trans;
	}
	
	
	
}
