package com.loan.ui;

import java.util.Scanner;
import com.loan.bean.Account;
import com.loan.service.LoanServiceImpl;

public class Client {

	public static void main(String[] args) {
	
		LoanServiceImpl service = new LoanServiceImpl();
		Scanner sc = new Scanner(System.in);
		char n;
		int acno;
		while(true)
		{
			System.out.println();
			System.out.println("\t\t********** Welcome to ABC Bank **********");
			System.out.println("A. Create Loan Account \nB. Show Account Details \nC. Check Balance \nD. Deposit Amount \nE. Apply for Loan \nF. Calculate EMI of Loan \nG. Pay EMI \nH. Loan Foreclose \nI. Print Transactions \nJ. Exit");
			System.out.println("Please Enter Your Choice:");
			n = sc.next().charAt(0);
			switch (n) 
			{
			
			//Account Creation
				case 'A':	
					System.out.println("Enter Your Name (*Enter only Characters & Minimun 3 Maximum 15 characters): ");
					String name=sc.next();
					System.out.println("Enter UID (*Last four digits of your Aadhar): ");
					String id =sc.next();
					System.out.println("Enter Your Mobile Number (*Length must be of 10 digits): ");
					String phno=sc.next();
					System.out.println("Enter Secure Deposit Amount (*Min Rs.50,000/-):");
					String blc=sc.next();
					System.out.println("Enter password (*length must be of 4 characters): ");
					String pass = sc.next();
					
					if(name.matches("^[a-zA-Z]*$") && name.length()>=3 &&name.length()<=15 && id.matches("^[0-9]*$") && id.length()==4 && phno.matches("^[0-9]*$") && phno.length()==10 && blc.matches("^[0-9]*$") && Double.parseDouble(blc)>=50000 && pass.matches("^[a-zA-Z0-9]*$")&& pass.length()==4)
					{	
							double bal = Double.parseDouble(blc);
							Account a = new Account(name,phno,bal,id,pass);
							int i=service.addAccount(a);
							if(i!=0)
							{
								System.out.println("Hello "+a.getFirstName()+", "+"Your Account has been Created.");
								System.out.println("Your Account Number is: "+ i);
							}
							else
							{
								System.out.println("Account already exist");
							}
					}
					else
							System.out.println("Invalid Data Entered");
				break;
				
			//Show account details
				case 'B':  	
					
					System.out.println("Enter Account Number:");
					String acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
						
					System.out.println("Enter Password: ");
					String p1 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p1))
					{
						System.out.println("\n*******************************");
						System.out.println("\tAccount Details");
						System.out.println("*******************************");
						Account a1= service.findAcc(acno);
						System.out.println(a1);
					}
					else
					{
						System.out.println("Invalid Account number or password");
					}
					
					
				break;	
					   
			//check balance	   
				case 'C':
					
					System.out.println("Enter Account Number:");
					acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p2 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p2))
					{
					
							double b= service.checkBalance(acno);
							System.out.println("Balance: Rs."+b);
					}
					else
					{
							System.out.println("Transcation Falied! Invalid Account number or password");
					}
					
				break;
						
			//deposit amount
				case 'D': 
					System.out.println("Enter Account Number:");
					 acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p3 = sc.next();
					acno =Integer.parseInt(acno1);	
					if(service.passValidate(acno, p3))
					{
						System.out.println("Enter Amount to deposit: ");
						String bal1 = sc.next();
						
						if(bal1.matches("^[0-9]*$"))
							{
								double b= service.depositAmt(acno, Double.parseDouble(bal1));
	
								if(b!=0)
								{
									System.out.println("Rs."+b+" is deposited in your account");
								}
								else
								{
									System.out.println("Invalid data entered");
								}
							}
						else
							System.out.println("Invalid data entered");
						
					}
					else
					{
						System.out.println("Transcation Falied! Invalid Account number or password");
					}

				break;
						
			//Apply Loan
				case 'E': 	
					System.out.println("Enter Account Number:");
					acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p4 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p4))
					{	
						System.out.println("Enter Amount for Loan:");
						String l = sc.next();
						System.out.println("Enter Asset Value:");
						String ast =sc.next();
						if(l.matches("^[0-9]*$")  && ast.matches("^[0-9]*$"))
						{
							Double loan = Double.parseDouble(l);
							double assetValue = Double.parseDouble(ast);
						double s3 = service.loanApply(acno,loan, assetValue);
						if(s3!=0 && s3 >0)
						{
						System.out.println("Your Loan Application for Amount Rs."+s3+" is Processed successfully");
						}
						else if(s3 == 0)
						{
							System.out.println("Invalid data entered");
						}
						else if(s3 == -1)
						{
							System.out.println("Sorry! You are not elgible for Loan");
						}
						else
						{
							System.out.println("Loan exist");
						}
					}
					}
					else
					{
						System.out.println("Invalid Account number or password");
					}
					
				break;	
						
			//EMI Calculation		
				case 'F': 
					 System.out.println("Enter Account Number:");
					 acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p5 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p5))
					{		
							
							double s3 = service.calcEmi(acno);
							if(s3!= 0 && s3>0)
								System.out.println("Rs."+s3+" is your monthly EMI");
							else if(s3 == -1)
							{
								System.out.println("Invalid data entered");
							}
							
							else
								System.out.println("No Loans exist on this Account Number");	
					}
					else
					{
						System.out.println("Invalid Account number or password");
					}
	
				break;
						
			//pay EMI 
				case 'G': 
					System.out.println("Enter Account Number:");
					 acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p6 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p6))
					{			
						double s3 = service.loanEmi(acno);
						if(s3!=0)
						{
							System.out.println("Rs."+s3+" is paid towards your loan repayment");
						}
						else if(s3 ==-1)
						{
							System.out.println("Transaction failed due to insufficient funds");
						}
						if(s3==0)
						{
							System.out.println("No Pending Loans on this Account Number");
						}
					}
					else
					{
						System.out.println("Invalid Account number or password");
					}
					
					
				break;	
					
			//Foreclose Loan	
				case 'H': 
					
					System.out.println("Enter Account Number:");
					 acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p7 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p7))
					{			
						int l= service.loanForeclose(acno);
						if(l==1)
						{
							System.out.println("No Loans exist on this Account Number");
						}
						else
						{
							System.out.println("Loan Foreclosure succesful");
						}
					}
					else
					{
						System.out.println("Invalid Account number or password");
					}
					
				break;	
				
			//print transactions
				case 'I': 
					
					System.out.println("Enter Account Number:");
					 acno1 = sc.next();
					while(!acno1.matches("^[0-9]*$"))
					{
						System.out.println("Wrong Input!\nEnter Account Number:");
						acno1 = sc.next();
					}
					System.out.println("Enter Password: ");
					String p8 = sc.next();
					acno =Integer.parseInt(acno1);
					if(service.passValidate(acno, p8))
					{			
						System.out.println("\n*******************************");
						System.out.println("    Your Account transactions");
						System.out.println("*******************************");
						System.out.println("Transaction ID"+"\t\t"+"Transaction");
						System.out.println("--------------------------------------");
						String str= service.printTransactions(acno);
						System.out.println(str);
					}
					else
					{
					System.out.println("Invalid Account number or password");
					}
				break;	
				
			//Exit
				case 'J':
					System.exit(0);
					
				default:System.out.println("Enter proper choice");
						break;
			}
		}
	}
}
