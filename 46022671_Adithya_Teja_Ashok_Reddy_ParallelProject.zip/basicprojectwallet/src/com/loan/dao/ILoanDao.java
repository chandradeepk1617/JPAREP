package com.loan.dao;

import java.util.List;

import com.loan.bean.Account;
import com.loan.bean.Transactions;

public interface ILoanDao {
	public int generateAccNo(Account acc);
	public void commitTrans(Transactions t);
	public int addAccount(Account acc);		
	public Account findAcc(int accNo);
	public double checkBalance(int accNo);
	public double depositAmt(int accNo, double bal);
	public double loanApply(int accNo,double loan,double assetvalue);
	public double calcEmi(int accNo);
	public double loanEmi(int accNo);
	public void loanForeclose(int accNo);
	public List<Transactions> printTransactions(int accNo);
	public boolean passValidate(int accNo, String pass);
	public void transactionBegin();
	public void transactionCommit();

}
