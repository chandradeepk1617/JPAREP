package com.loan.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import java.lang.Math;
import com.loan.bean.Account;
import com.loan.bean.Transactions;



public class LoanDaoImpl implements ILoanDao{
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
	EntityManager em =emf.createEntityManager();
	
	static int a =100000;
	
	//Generate Account Number
		@Override
		public int generateAccNo(Account acc)
		{
			String qStr = "SELECT id FROM Account";
			TypedQuery<String> query = em.createQuery(qStr, String.class);
			List<String>usr= query.getResultList();
			if(!usr.contains(acc.getUid())&& !usr.isEmpty())
			{
				em.getTransaction().begin();
				String Str = "SELECT max(accNumber) FROM Account";
				TypedQuery<Integer> query1 = em.createQuery(Str, Integer.class);
				int num= query1.getSingleResult();
				em.getTransaction().commit();
				return num;
			}
			else if(usr.isEmpty())
			{			
				return a;
			}
			else
			{
				return 0;
			}
	}

//Account Creation 
		@Override
		public int addAccount(Account acc) {
			transactionBegin();
			Transactions tr= new Transactions(); 
			tr.setAccNumber(acc.getAccNumber());
			tr.setTransId(1);
			tr.setTrans(acc.getBalanceAmt()+" Deposited");
			em.persist(acc);
			em.persist(tr);
			em.getTransaction().commit();
			return acc.getAccNumber();
		}
		
	//Commit Transactions
		@Override
		public void commitTrans(Transactions t) {
			transactionBegin(); 
			em.persist(t);
			transactionCommit();
		}
		
	//commit Both Account and Transactions
		public void commit(Account a, Transactions t) {
			transactionBegin();
			em.merge(a);
			em.persist(t);
			transactionCommit();
		}
		
	//Find Account of user 
		@Override
		public Account findAcc(int accNo) {
			
			Account a = em.find(Account.class, accNo);
			return a;
		}
		

	//Balance check
		@Override
		public double checkBalance(int accNo) {
			Account a = em.find(Account.class, accNo);
			return a.getBalanceAmt();

		}

	//deposit amount
		@Override
		public double depositAmt(int accNo, double bal1) {
				transactionBegin();
				Account a = em.find(Account.class, accNo);
				em.merge(a);
				transactionCommit();
				return bal1;
			}

	//Apply Loan
		@Override
		public double loanApply(int accNo,double loan,double assetvalue) {
			transactionBegin();
			Account a = em.find(Account.class, accNo);
			em.merge(a);
			transactionCommit();
			return loan;	
		}

	//Calculate EMI
		@Override
		public double calcEmi(int accNo) {
			transactionBegin();
			Account a = em.find(Account.class,accNo);
			em.merge(a);
			transactionCommit();
			return a.getEmi();
		}
		
	//Pay EMI
		@Override
		public double loanEmi(int accNo) {
			transactionBegin();
			Account a= findAcc(accNo);
			em.merge(a);
			transactionCommit();
			return a.getEmi();
		}

	//Foreclose Loan
		@Override
		public void loanForeclose(int accNo) {
			transactionBegin();
			Account a= findAcc(accNo);
			em.merge(a);
			transactionCommit();
		}

	//Print Transactions
		@Override
		public List<Transactions> printTransactions(int accNo) {

			Account a = em.find(Account.class,accNo);
			
			String qStr2 = "SELECT t FROM Transactions t WHERE t.transId between :start and :end and t.accNumber= :num order by t.transId desc";
			TypedQuery<Transactions> query = em.createQuery(qStr2, Transactions.class);

			query.setParameter("start",1);
			query.setParameter("end",a.getTransCount());
			query.setParameter("num", accNo);
				
			List<Transactions> t = query.getResultList();
			
			return t;
		
		}

	//Password Validation
		@Override
		public boolean passValidate(int accNo, String pass) {
			try
			{
			String qStr = "SELECT pass FROM Account where accNumber =:num";
			TypedQuery<String> query = em.createQuery(qStr, String.class);
			query.setParameter("num", accNo);
			String pwd = query.getSingleResult();

			if(pwd.equals(pass)&& pwd != null)
			{
				return true;
			}
			else 
				return false;
			}catch(Exception e)
			{
				return false;
			}
		}

	//Begin Transaction
		@Override
		public void transactionBegin() {
			em.getTransaction().begin();
			
		}

	//Commit transaction
		@Override
		public void transactionCommit() {
			em.getTransaction().commit();
			
		}
}
