package com.loan.junit;

import static org.junit.Assert.*;
import org.junit.Test;

import com.loan.bean.Account;
import com.loan.service.ILoanService;
import com.loan.service.LoanServiceImpl;

public class AccountTest {

	ILoanService service= new LoanServiceImpl();
	Account a1= new Account("Prithve","7410852963",700000,"1780","1234");
	
	//Default test case
	@Test
	public void test1()
	{
		Account a =new Account();
		assertEquals(null, a.getFirstName());
		assertEquals(0, a.getAccNumber());
		assertEquals(0.0, a.getBalanceAmt(),1);
		assertEquals(null, a.getPhNo());
		assertEquals(null, a.getUid());
	}
	
	//Account Creation 
	
	/*It will work only once as account number and id has to be unique. It will return 0
	@Test
	public void test2() 
	{
		int acNo1=service.addAccount(a1);		
		assertEquals(100007,acNo1);
	}
	*/
	
	//check balance of  a bean
	@Test
	public void test3()
	{
		double bal = a1.getBalanceAmt();
		assertEquals(700000, bal, 1);
	}
	
	//check balance
	@Test
	public void test4()
	{
		int b=(int)service.checkBalance(100001);
		assertEquals(30000, b);
	}

	//deposit amount
	@Test
	public void test5()
	{
		double str = service.depositAmt(100002, 100.25);
		assertEquals(100.25,str,1);
	}
	
	//Calculate EMI
	@Test
	public void test6()
	{
		double str= service.calcEmi(100005);
		assertEquals(2167.0, str,1);
			
	}
		
	//Pay EMI
	//It will run until there exists a loan gets cleared 
	@Test
	public void test7()
	{
		
		double str = service.loanEmi(100005);
		assertEquals(2167.0,str,1);
	}
	
	//Password Check
	@Test
	public void test8()
	{
		boolean str =service.passValidate(100001, "adit");
		assertEquals(true, str);
	}
	
	//loan Forclose
	/*It will run only once. If we run more than once it will return 0.0;
	@Test
	public void test9()
	{
		int str =service.loanForeclose(100005);
		assertEquals(2, str,1);
				
	}
	*/

}
