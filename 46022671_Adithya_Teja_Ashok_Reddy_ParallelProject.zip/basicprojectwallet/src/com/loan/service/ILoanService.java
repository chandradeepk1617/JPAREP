package com.loan.service;

import com.loan.bean.Account;

public interface ILoanService {
	public int addAccount(Account acc);
	public Account findAcc(int accNo);
	public double checkBalance(int accNo);
	public double depositAmt(int accNo, double bal);
	public double loanApply(int accNo,double loan,double assetvalue);
	public double loanEmi(int accNo);
	public double calcEmi(int accNo);
	public int loanForeclose(int accNo);
	public String printTransactions(int accNo);
	public boolean passValidate(int accNo, String pass);
}
