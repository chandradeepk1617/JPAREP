package com.loan.service;

import java.util.List;
import java.util.Scanner;

import com.loan.bean.Account;
import com.loan.bean.Transactions;
import com.loan.dao.LoanDaoImpl;

public class LoanServiceImpl implements ILoanService {
	Scanner sc =new Scanner(System.in);
	
	LoanDaoImpl ldi;
	public LoanServiceImpl() {
		ldi =new LoanDaoImpl();
	}

//Account Creation 
	@Override
	public int addAccount(Account acc)
	{
		int i= ldi.generateAccNo(acc);
		if(i!=0)
		{
			acc.setAccNumber(i+1);
			acc.setEmi(0.0);
			acc.setLoanAmount(0.0);
			acc.setTransCount(1);
			int l=ldi.addAccount(acc);
			return l;
		}
		else
			return 0;
	}
	
	//Find Account of user
	@Override
	public Account findAcc(int accNo) {
		return ldi.findAcc(accNo);
	}
	
	//Balance check
	@Override
	public double checkBalance(int accNo) {
		return ldi.checkBalance(accNo);
	}

	//deposit amount
	@Override
	public double depositAmt(int accNo, double bal) {
		if(bal>0)
		{
			Account a= ldi.findAcc(accNo);
			double b= a.getBalanceAmt();
			double set = b+bal;
			a.setBalanceAmt(set);
	
			Transactions tr= new Transactions();
			tr.setAccNumber(a.getAccNumber());
			tr.setTransId(a.getTransCount()+1);
			tr.setTrans(bal+" Credited");
			a.setTransCount(a.getTransCount()+1);
			ldi.commit(a,tr);
			return bal;
		}
		else
		{
			return 0;
		}
		
	}
	
	//Apply Loan
	@Override
	public double loanApply(int accNo,double loan,double assetvalue) {
		
		Account a = ldi.findAcc(accNo);
		System.out.println("Hello "+a.getFirstName()+", Welcome to Loan Sector");
		if(a.getLoanAmount() == 0.0)
		{
			if(assetvalue > 100000 && assetvalue > loan && a.getBalanceAmt()>=50000 )
			{	
				a.setLoanAmount(loan);
				double e= calcEmi(accNo);
				if(e!=0)
				{
					a.setEmi(e);
					return ldi.loanApply(accNo,loan,assetvalue);
				}
				else
				{
					return 0;
				}		
			}
		
			else
			{
				return -1;
			}
		}
		else
		{
			return -2;
		}
	}

	//Calculate EMI
	@Override
	public double calcEmi(int accNo) {
		Account a=ldi.findAcc(accNo);
		if(a.getEmi()==0.0)
		{
			if(a.getLoanAmount()!=0.0)
			{
				System.out.println("Enter Tenure for loan clearence(in Yrs): ");
				String y=sc.next();
				if(y.matches("^[0-9]*$"))
				{
					int t =Integer.parseInt(y);
					double b=a.getLoanAmount();
					int r =2;
					double emi = Math.ceil((b+(b*r*t)/100)/(t*12));
					return emi;
				}
				else
					return -1;
				}
			else return 0;
			
		}
		else
			return ldi.calcEmi(accNo);
	}
	
	//Pay EMI
	@Override
	public double loanEmi(int accNo) {
		Account a =  ldi.findAcc(accNo);
		double b = a.getLoanAmount();
		if(b==0.0)
		{
			return 0;
		}
		else {
			System.out.println("Your pending Loan Amount: Rs."+b);
			double b1 =a.getBalanceAmt();
			System.out.println("Your Account Balance: Rs."+b1);
			double pay = a.getEmi();		
				if(pay<=b1 && pay<=b)
				{
					double set1 =b-pay;
					double set2 =b1-pay;
					a.setBalanceAmt(set2);
					a.setLoanAmount(set1);
					Transactions tr= new Transactions();
					tr.setAccNumber(a.getAccNumber());
					tr.setTransId(a.getTransCount()+1);
					tr.setTrans(pay+" Debited");
					a.setTransCount(a.getTransCount()+1);
					ldi.commitTrans(tr);
					return ldi.loanEmi(accNo);
					
				}
				else
				{
					return -1;
				}
			}
	}

	//Foreclose Loan
	@Override
	public int loanForeclose(int accNo) {
		Account a = ldi.findAcc(accNo);
		double b = a.getLoanAmount();
		if(b==0.0)
		{
			return 1;
		}
		else
		{
		System.out.println("Your pending Loan Amount: Rs."+b);
		double b1 =a.getBalanceAmt();
		System.out.println("Your Account Balance: Rs."+b1);
		
			if(b1>b)
			{
				double set3 = b1-b;
				a.setBalanceAmt(set3);
				a.setLoanAmount(0.0);
				a.setEmi(0.0);
				Transactions tr= new Transactions();
				tr.setAccNumber(a.getAccNumber());
				tr.setTransId(a.getTransCount()+1);
				tr.setTrans(b+" Debited");
				a.setTransCount(a.getTransCount()+1);
				ldi.commitTrans(tr);
				ldi.loanForeclose(accNo);
				return 2;
				
			}
			else
			{
				a.setLoanAmount(0.0);
				a.setEmi(0.0);
				a.setBalanceAmt(0.0);
				Transactions tr= new Transactions();
				tr.setAccNumber(a.getAccNumber());
				tr.setTransId(a.getTransCount()+1);
				tr.setTrans(b+" Debited");
				a.setTransCount(a.getTransCount()+1);
				ldi.commitTrans(tr);
				ldi.loanForeclose(accNo);
				return 2;
			}
		}
			
	}

	//Print Transactions
	@Override
	public String printTransactions(int accNo) {
		String w1="";
		
		List<Transactions> t= ldi.printTransactions(accNo);
				
		for(int i=0;i<t.size();i++) {
			w1 = w1 +"\t" +t.get(i).getTransId()+"\t\t"+t.get(i).getTrans()+"\n";
		}
		return w1;
	}

	//Password Validation
	@Override
	public boolean passValidate(int accNo, String pass) {
		
		return ldi.passValidate(accNo, pass);
	}
}
